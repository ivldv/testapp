<section class="news">
	<div class="container pl-0 pr-0">
		<h3 class="news-maintitle">Новости</h3>
		<div class="row">
			<div class="col-12 col-md-4 pl-0 pr-0 mr-15">
				<div class="news-img">
					<div class="news-foto">
						<img src="src/img/main/layer-12.jpg" alt="">
						<div class="news-foto__overlay"></div>
					</div>
					<div class="news-date">22 Февраля 2018</div>
					<div class="news-title">Часть избирательных участков </div>
					<div class="news-text">Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым.</div>
					<a href="#" class="link-info">Читать статью</a>
				</div>
			</div>
			<div class="col-12 col-md-4 pl-0 pr-0 mr-15 ml-15">
				<div class="news-img">
					<div class="news-foto">
						<img src="src/img/main/layer-13.jpg" alt="">
						<div class="news-foto__overlay"></div>
					</div>
					<div class="news-date">22 Февраля 2018</div>
					<div class="news-title">В Избиркоме Югры прошли </div>
					<div class="news-text">Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым.</div>
					<a href="#" class="link-info">Читать статью</a>
				</div>
			</div>
			<div class="col-12 col-md-4 pl-0 pr-0 ml-15">
				<div class="news-img">
					<div class="news-foto">
						<img src="src/img/main/layer-14.jpg" alt="">
						<div class="news-foto__overlay"></div>
					</div>
					<div class="news-date">22 Февраля 2018</div>
					<div class="news-title">В Югре напечатаны и переданы</div>
					<div class="news-text">Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым.</div>
					<a href="#" class="link-info">Читать статью</a>
				</div>
			</div>
		</div>
	</div>
</section>