<div class="container footer">
	<div class="row footer__row">
		<div class="col-12 col-md-3 footer-media">
			<div class="footer-title">Навигация</div>
			<a href="<?echo($_SERVER['SCRIPT_URL'])?>" class="footer-link">О предприятии</a>
			<a href="<?echo($_SERVER['SCRIPT_URL'])?>?id=1" class="footer-link">Новости</a>
			<a href="<?echo($_SERVER['SCRIPT_URL'])?>?id=2" class="footer-link">Бронь билетов</a>
			<a href="" class="footer-link">Для пассажиров</a>
			<a href="" class="footer-link">Расписание и цены</a>
		</div>
		<div class="col-12 col-md-3 footer-media">
			<div class="footer-title">Информация</div>
			<a href="" class="footer-link">Партнерам</a>
			<a href="" class="footer-link">СМИ</a>
			<a href="<?echo($_SERVER['SCRIPT_URL'])?>?id=1" class="footer-link">Вакансии</a>
			<a href="<?echo($_SERVER['SCRIPT_URL'])?>?id=1" class="footer-link">Правовая информация</a>
			<a href="" class="footer-link">Контакты</a>
		</div>
		<div class="col-12 col-md-3 footer-media">
			<div class="footer-title">Контакты</div>
			<div class="footer-link__wrap">
							<a href="" class="footer-link__img"><i class="fa fa-vk" aria-hidden="true"></i></a>
			</div>
			<div class="footer-link__wrap">
			<a href="" class="footer-link__img"><i class="fa fa-facebook" aria-hidden="true"></i></a>
		</div>
			<div class="footer-link__wrap">
			<a href="" class="footer-link__img"><i class="fa fa-twitter" aria-hidden="true"></i></a>
		</div>
			<a href="tel:+78003389578" class="footer-link footer-link__tel">8-800-338-95-78</a>
			<a href="maill:mortrans@site.ru" class="footer-link footer-link__email">mortrans@site.ru</a>
		</div>
		<div class="col-12 col-md-3 footer-media">
			<div class="footer-title">Правовая информация</div>
			<div class="footer-text">Информация, представленная 
на сайте не является публичной офертой и предоставляетя 
на правах рекламы.</div>
			<a href="src/img/politikaconf.pdf" class="footer-link">Политика конфиденциальности</a>
		</div>
	</div>
	<p class="footer-signature">© 2018 - Танспортная компания МорТранс</p>
</div>