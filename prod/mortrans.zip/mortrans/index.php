<?//print_r($_SERVER );?>
<?include ("main_tamplete.php");

